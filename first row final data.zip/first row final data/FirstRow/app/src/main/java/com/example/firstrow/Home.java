package com.example.firstrow;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.NavigationUI;
import androidx.viewpager.widget.ViewPager;

import android.graphics.pdf.PdfDocument;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

public class Home extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{

    Toolbar toolbar;
    public NavController navController;
    public DrawerLayout Home_Drawer_Layout;
    public NavigationView HomeNavigationView;
    private ViewPager viewPager;
    View view;
  // private TabLayout tabLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        toolbar = findViewById(R.id.home_toolbar);
        setupNavDrawer();
    }

    private void setupNavDrawer() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Home_Drawer_Layout = findViewById(R.id.HomeDrawer);
        HomeNavigationView = findViewById(R.id.home_navigationview);

        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this,Home_Drawer_Layout,R.string.app_name,R.string.app_name);
        toolbar.setNavigationIcon(R.drawable.menu_icon);
        actionBarDrawerToggle.syncState();


        //Navigation Controller Setup
        navController = Navigation.findNavController(this,R.id.nav_home_host_fragment);
        NavigationUI.setupActionBarWithNavController(this,navController,Home_Drawer_Layout);
        NavigationUI.setupWithNavController(HomeNavigationView,navController);

        HomeNavigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public boolean onSupportNavigateUp() {
        return NavigationUI.navigateUp(Navigation.findNavController(this, R.id.nav_home_host_fragment),Home_Drawer_Layout) || super.onSupportNavigateUp();
    }

    @Override
    public void onBackPressed() {
        if (Home_Drawer_Layout.isDrawerOpen(GravityCompat.START)) {
            Home_Drawer_Layout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        Home_Drawer_Layout.close();
        int Selected_item = menuItem.getItemId();
        switch (Selected_item) {
            case R.id.drawer_menu_newsFeed:
                Home_Drawer_Layout.close();
                //Toast.makeText(this,"News Feed Clicked!",Toast.LENGTH_LONG).show();
                //navController.navigate(R.id.action_homeFrag_to_home_TabPage12);
                break;
            case R.id.drawer_menu_setting:
                navController.navigate(R.id.action_homeFrag_to_settingFrag);
                //Toast.makeText(this,"Settings Clicked!",Toast.LENGTH_LONG).show();
                break;
        }

        return false;
    }
}
