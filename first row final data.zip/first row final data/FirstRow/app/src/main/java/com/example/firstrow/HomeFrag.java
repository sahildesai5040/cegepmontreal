package com.example.firstrow;


import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TableLayout;

import com.google.android.material.tabs.TabLayout;


/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFrag extends Fragment {

    ViewPager viewPager;
    TabLayout tableLayout;
    ViewPagerAdapter viewPagerAdapter;


    public HomeFrag() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home2, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewPager = view.findViewById(R.id.pager);
        tableLayout = view.findViewById(R.id.tabLayout);
        setFragmentPageAdapter();
    }

    private void setFragmentPageAdapter() {
        viewPagerAdapter = new ViewPagerAdapter(getChildFragmentManager());
        viewPagerAdapter.AddFragment(new Home_TabPage1(),"home");
        viewPagerAdapter.AddFragment(new Table_TabPage2(),"table");
        viewPagerAdapter.AddFragment(new Profile_TabPage3(),"profile");
        viewPager.setAdapter(viewPagerAdapter);
        tableLayout.setupWithViewPager(viewPager);
        tableLayout.getTabAt(0).setText("Home");
        tableLayout.getTabAt(1).setText("Table");
        tableLayout.getTabAt(2).setText("Profile");
    }
}
