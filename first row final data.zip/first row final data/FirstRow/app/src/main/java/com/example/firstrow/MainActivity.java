package com.example.firstrow;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText email, password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        email=findViewById(R.id.et_email);
        password=findViewById(R.id.et_pass);
    }
    public void onClick(View v) {

        if (v.getId() == R.id.btn_signin) {
            if (email.getText().toString().equals("ben@gmail.com") &&
                    password.getText().toString().equals("pass1234")) {

                Intent I = new Intent(this, Home.class);
                startActivity(I);
            } else {
                Toast.makeText(this, "Invalid Login Details", Toast.LENGTH_LONG).show();
            }
        }
            if (v.getId() == R.id.tv_signup) {

                Intent I = new Intent(this, Signup.class);
                startActivity(I);
            }
    }


}
