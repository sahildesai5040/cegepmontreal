package com.example.firstrow;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Signup extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
    }

    public void onClick(View v){
        if(v.getId()==R.id.btn_signup){

            Intent I=new Intent(this, Home.class);
            startActivity(I);
        }
        if(v.getId()==R.id.tv_back) {

            Intent I=new Intent(this, MainActivity.class);
            startActivity(I);
        }
    }
}
